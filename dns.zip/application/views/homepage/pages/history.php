<div class="ibox-content">

    <h2>
        History
    </h2>
    <p>
        Hasil pasien.
    </p>
    <table class="table table-condensed table-striped table-hover" style="width:100%" id="history">
        <thead>
            <tr>
                <th>No.</th>
                <th>Nama Orangtua</th>
                <th>Nama Anak</th>
                <th>Alamat</th>
                <th>Umur</th>
                <!-- <th>Hasil</th> -->
                <th>Total</th>
                <th>Keterangan</th>
                <th>Tanggal</th>
            </tr>
        </thead>
    </table>

</div>