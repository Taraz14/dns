<div class="row border-bottom white-bg">
            <nav class="navbar navbar-expand-lg navbar-static-top" role="navigation">

                    <a href="<?= site_url();?>" class="navbar-brand">Penentuan Status Gizi</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fa fa-reorder"></i>
                    </button>

                <div class="navbar-collapse collapse" id="navbar">
                    <ul class="nav navbar-nav mr-auto">
                        <li class="active">
                            <!-- <a aria-expanded="false" role="button" href="<?= site_url('history'); ?>"> History</a> -->
                            <a aria-expanded="false" role="button" href="<?= site_url();?>">Home</a>
                        </li>
                        <li class="active">
                            <a aria-expanded="false" role="button" href="<?= site_url('history'); ?>"> History</a>
                        </li>

                        <!-- 
                        <li class="dropdown">
                            <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Menu</a>
                            <ul role="menu" class="dropdown-menu">
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Menu</a>
                            <ul role="menu" class="dropdown-menu">
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                            </ul>
                        </li>
                        <li class="dropdown">
                            <a aria-expanded="false" role="button" href="#" class="dropdown-toggle" data-toggle="dropdown"> Menu</a>
                            <ul role="menu" class="dropdown-menu">
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                                <li><a href="">item</a></li>
                            </ul>
                        </li> -->
                    </ul>
                    <ul class="nav navbar-top-links navbar-right">
                        <li>
                            <a href="<?= site_url('service/sign-in')?>">
                                <i class="fa fa-sign-in"></i> Login
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>