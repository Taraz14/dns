<?php
   defined('BASEPATH') OR exit('No direct script access allowed');

   require_once('header_script.php');
   require_once('navbar.php');
   require_once('content.php');
   // require_once('footer.php');
   require_once('end_script.php');
