<div class="footer">
            <div>
                <strong>Copyright</strong> Determination of Nutritional Status &copy; 2019-2020
            </div>
        </div>

        </div>
    </div>