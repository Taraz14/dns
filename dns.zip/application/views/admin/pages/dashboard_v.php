<div class="wrapper wrapper-content animated fadeInRight">
   <div class="row border-bottom white-bg dashboard-header">
      <div class="col-md-3">
         <h2>Welcome, ! <?= $this->session->userdata('name'); ?></h2>
      </div>
   </div>
</div>