<?php
   if($content){
      $this->load->view($content);
   }
?>