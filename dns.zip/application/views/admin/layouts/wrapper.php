<?php
   require_once('head_script.php');
   require_once('sidebar.php');
   require_once('navbar.php');
   require_once('content.php');
   require_once('footer.php');
   require_once('end_script.php');
?>